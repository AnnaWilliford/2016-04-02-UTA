#!/bin/bash
# this script collects data of user-specified index measured in a given year from all country-specific files
# usage: script.sh $inputFile $measure $year

input=$1
index=$2
year=$3

grep $index $input| grep $year | cut -f1,6 >> $index"_"$year.txt 